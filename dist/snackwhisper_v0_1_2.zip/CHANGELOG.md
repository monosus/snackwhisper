
# Change log

## [0.1.2] - 2024-06-09
### Added
- 出力エンコーディングの指定をconfig.iniに追加

## [0.1.1] - 2024-05-22
- first release

# Template
## [version] - DATE
### Added
### Changed
### Deprecated
### Removed
### Fixed
### Security
