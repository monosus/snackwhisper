
# Change log

## [0.1.4] - 2025-03-23
### Added
- Transcriptionのモデルを選べるドロップダウンを追加
- 従来のwhisper-1に加えて、gpt-4o-transcribe と gpt-4o-mini-transcribe を選べる

### Changed
- バージョン番号を 0.1.3 から 0.1.4 に更新

## [0.1.3] - 2024-06-11
### Added
- デバッグ用のフラグを config.ini から指定する機能を追加

### Fixed
- 長時間の文字起こしでエラーが発生して停止する不具合を修正
- ファイル分割が発生した際のタイムスタンプを修正

## [0.1.2] - 2024-06-09
### Added
- 出力エンコーディングの指定をconfig.iniに追加

## [0.1.1] - 2024-05-22
- first release

# Template
## [version] - DATE
### Added
### Changed
### Deprecated
### Removed
### Fixed
### Security
